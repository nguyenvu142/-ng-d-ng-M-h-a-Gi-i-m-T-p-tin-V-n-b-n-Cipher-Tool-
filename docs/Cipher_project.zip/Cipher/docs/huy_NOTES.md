# Ghi chú của Huy (B): Caesar, Vigenere và bảng tra

## 1. Mục tiêu

- Hiểu công thức Caesar và Vigenere để có thể tự tính tay.
- Ghi lại pseudocode tiếng Việt để đối chiếu với chương trình C.
- Dùng vector kiểm thử cố định trong `tests/vectors.txt`.
- Đối chiếu kết quả bằng một cách tính độc lập, không chỉ dựa vào code C.

## 2. Quy ước chữ cái

Quy ước A = 0, B = 1, ..., Z = 25. Chỉ các chữ cái ASCII A-Z được biến đổi trong chế độ chữ cái; khoảng trắng, dấu câu và ký tự khác được giữ nguyên. Với chế độ byte, mỗi byte có giá trị từ 0 đến 255.

## 3. Caesar Cipher — chế độ chữ cái

### Công thức

- Mã hóa: `C = (P + k) mod 26`
- Giải mã: `P = (C - k + 26) mod 26`

Trong đó P là giá trị chữ cái gốc, C là chữ cái sau biến đổi, k là số dịch chuyển.

### Pseudocode tiếng Việt

```text
HÀM Caesar_ChuCai(chuoi, khoa, giai_ma):
    dịch = khoa mod 26
    NẾU giai_ma thì dịch = (26 - dịch) mod 26
    DUYỆT từng ký tự trong chuỗi:
        NẾU ký tự thuộc 'A'..'Z':
            đổi ký tự thành 'A' + ((ký_tự - 'A' + dịch) mod 26)
        NGƯỢC LẠI NẾU ký tự thuộc 'a'..'z':
            đổi ký tự thành 'a' + ((ký_tự - 'a' + dịch) mod 26)
        NGƯỢC LẠI:
            giữ nguyên ký tự
    TRẢ VỀ chuỗi
```

### Ví dụ tính tay 1: `HELLO`, khóa 3

- H = 7; (7 + 3) mod 26 = 10 = K
- E = 4; (4 + 3) mod 26 = 7 = H
- L = 11; (11 + 3) mod 26 = 14 = O
- L = 11; (11 + 3) mod 26 = 14 = O
- O = 14; (14 + 3) mod 26 = 17 = R

Kết quả mã hóa: `KHOOR`. Giải mã `KHOOR` với khóa 3 sẽ thu lại `HELLO`.

### Ví dụ tính tay 2: vòng qua cuối bảng chữ cái

`XYZ` với khóa 3:
- X = 23; (23 + 3) mod 26 = 0 = A
- Y = 24; (24 + 3) mod 26 = 1 = B
- Z = 25; (25 + 3) mod 26 = 2 = C

Kết quả: `ABC`.

## 4. Caesar Cipher — chế độ byte

### Công thức

- Mã hóa: `C = (P + k) mod 256`
- Giải mã: `P = (C - k + 256) mod 256`

### Pseudocode tiếng Việt

```text
HÀM Caesar_Byte(mang_byte, khoa, giai_ma):
    dịch = khoa mod 256
    NẾU giai_ma thì dịch = (256 - dịch) mod 256
    DUYỆT từng byte b:
        b = (b + dịch) mod 256
    TRẢ VỀ mảng byte
```

### Ví dụ tính tay 3: tràn byte

Byte `0xFF` bằng 255. Với khóa 1: `(255 + 1) mod 256 = 0`, tức `0x00`. Giải mã: `(0 + 256 - 1) mod 256 = 255`, tức `0xFF`.

## 5. Vigenere Cipher — chế độ chữ cái

### Công thức

Đổi A=0, ..., Z=25. Lặp khóa cho đủ độ dài văn bản.
- Mã hóa: `C[i] = (P[i] + K[i]) mod 26`
- Giải mã: `P[i] = (C[i] - K[i] + 26) mod 26`

Trong chế độ chữ cái, khóa chỉ tiến sang ký tự tiếp theo khi gặp chữ cái ASCII. Dấu cách và dấu câu được giữ nguyên, không làm dịch vị trí khóa.

### Pseudocode tiếng Việt

```text
HÀM Vigenere_ChuCai(chuoi, khoa, giai_ma):
    NẾU khóa rỗng thì báo lỗi
    vị_trí_khóa = 0
    DUYỆT từng ký tự trong chuỗi:
        NẾU ký tự là chữ ASCII:
            P = giá trị ký tự (A/a tương ứng 0)
            K = giá trị chữ khóa tại vị_trí_khóa
            NẾU mã hóa: C = (P + K) mod 26
            NẾU giải mã: C = (P - K + 26) mod 26
            chuyển C về chữ hoa/thường tương ứng
            vị_trí_khóa = (vị_trí_khóa + 1) mod độ_dài_khóa
        NGƯỢC LẠI:
            giữ nguyên ký tự và không tăng vị_trí_khóa
    TRẢ VỀ chuỗi
```

### Ví dụ tính tay 4: `ATTACKATDAWN`, khóa `LEMON`

Khóa lặp lại: `LEMONLEMONLE`.

| Vị trí | Bản rõ | P | Khóa | K | (P+K) mod 26 | Bản mã |
|---:|:---:|---:|:---:|---:|---:|:---:|
| 1 | A | 0 | L | 11 | 11 | L |
| 2 | T | 19 | E | 4 | 23 | X |
| 3 | T | 19 | M | 12 | 5 | F |
| 4 | A | 0 | O | 14 | 14 | O |
| 5 | C | 2 | N | 13 | 15 | P |
| 6 | K | 10 | L | 11 | 21 | V |
| 7 | A | 0 | E | 4 | 4 | E |
| 8 | T | 19 | M | 12 | 5 | F |
| 9 | D | 3 | O | 14 | 17 | R |
| 10 | A | 0 | N | 13 | 13 | N |
| 11 | W | 22 | L | 11 | 7 | H |
| 12 | N | 13 | E | 4 | 17 | R |

Kết quả mã hóa: `LXFOPVEFRNHR`. Dùng khóa `LEMON` để giải mã sẽ thu lại `ATTACKATDAWN`.

## 6. Vigenere Cipher — chế độ byte

Trong chế độ byte, mỗi ký tự khóa được dùng như một giá trị byte (0..255). Với khóa byte `K[i]`:
- Mã hóa: `C[i] = (P[i] + K[i]) mod 256`
- Giải mã: `P[i] = (C[i] - K[i] + 256) mod 256`

Biến `offset` ghi nhớ vị trí tiếp theo trong khóa. Sau mỗi byte được xử lý, cập nhật `offset = (offset + 1) mod độ_dài_khóa`. Khóa rỗng phải bị từ chối vì không thể lấy phần dư theo độ dài 0.

## 7. Bảng tra cứu

- `CAESAR_ENC[x] = (x + 1) mod 256`: bảng mã hóa byte với dịch chuyển 1.
- `CAESAR_DEC[x] = (x + 255) mod 256`: bảng ngược tương ứng.
- `VIGENERE_TABLE[row][col] = 'A' + (row + col) mod 26`: bảng 26×26, trong đó hàng là chữ khóa và cột là chữ bản rõ (theo quy ước A=0).
- Các bảng được sinh bằng vòng lặp trong `tables_init()`, không cần viết tay từng phần tử.

## 8. Kiểm tra khóa

- Caesar chữ cái: khóa 0 hoặc bội số của 26 không làm thay đổi chữ cái; cần cảnh báo người dùng.
- Caesar byte: khóa 0 hoặc bội số của 256 không làm thay đổi byte; cần cảnh báo người dùng.
- Vigenere: khóa rỗng phải báo lỗi. Ở chế độ chữ cái, chỉ chấp nhận A-Z/a-z để công thức chữ cái có nghĩa rõ ràng.

## 9. Độ phức tạp và giới hạn an toàn

- Thời gian: O(n), với n là số byte/ký tự cần xử lý.
- Bộ nhớ phụ: O(1) nếu xử lý trực tiếp từng phần tử trong bộ đệm; không tính bộ đệm đầu vào.
- Caesar và Vigenere cổ điển dễ bị phân tích tần suất và không phù hợp để bảo vệ dữ liệu nhạy cảm. Chỉ nên dùng cho mục đích học thuật; ứng dụng thực tế nên dùng thuật toán hiện đại như AES-GCM qua thư viện uy tín.

## 10. Đối chiếu độc lập

Các vector trong `tests/vectors.txt` được đối chiếu bằng công thức toán học và một phép tính tham chiếu độc lập (không gọi các hàm C của dự án). Khi kiểm thử, so sánh cả kết quả mã hóa và việc giải mã có khôi phục đúng bản rõ hay không.

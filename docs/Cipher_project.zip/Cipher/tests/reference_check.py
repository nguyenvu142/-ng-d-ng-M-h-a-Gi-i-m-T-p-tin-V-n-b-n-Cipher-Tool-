"""Independent reference checks for the classic Caesar and Vigenere vectors."""


def caesar_letters(text: str, shift: int) -> str:
    result = []
    shift %= 26
    for ch in text:
        if "A" <= ch <= "Z":
            result.append(chr((ord(ch) - ord("A") + shift) % 26 + ord("A")))
        elif "a" <= ch <= "z":
            result.append(chr((ord(ch) - ord("a") + shift) % 26 + ord("a")))
        else:
            result.append(ch)
    return "".join(result)


def vigenere_letters(text: str, key: str, decrypt: bool = False) -> str:
    if not key:
        raise ValueError("Vigenere key must not be empty")
    key = key.upper()
    if not all("A" <= ch <= "Z" for ch in key):
        raise ValueError("Vigenere key must contain only A-Z")
    result = []
    key_pos = 0
    for ch in text:
        if "A" <= ch <= "Z":
            shift = ord(key[key_pos % len(key)]) - ord("A")
            if decrypt:
                shift = -shift
            result.append(chr((ord(ch) - ord("A") + shift) % 26 + ord("A")))
            key_pos += 1
        elif "a" <= ch <= "z":
            shift = ord(key[key_pos % len(key)]) - ord("A")
            if decrypt:
                shift = -shift
            result.append(chr((ord(ch) - ord("a") + shift) % 26 + ord("a")))
            key_pos += 1
        else:
            result.append(ch)
    return "".join(result)


def main() -> None:
    assert caesar_letters("HELLO", 3) == "KHOOR"
    assert caesar_letters("XYZ", 3) == "ABC"
    assert caesar_letters("KHOOR", -3) == "HELLO"
    assert vigenere_letters("ATTACKATDAWN", "LEMON") == "LXFOPVEFRNHR"
    assert vigenere_letters("LXFOPVEFRNHR", "LEMON", decrypt=True) == "ATTACKATDAWN"
    assert (0xFF + 1) % 256 == 0
    try:
        vigenere_letters("HELLO", "")
    except ValueError:
        pass
    else:
        raise AssertionError("Empty Vigenere key should fail")
    print("All reference vectors passed.")


if __name__ == "__main__":
    main()
